
public class Test1 {

	public static void main(String[] args) {
		long pop = 312032486;
		long yrInSec = 365*24*60*60;
		long diff = (yrInSec/7) - (yrInSec/13) + (yrInSec/45);
		
		System.out.println("The current population is " + pop);
		for (int x = 0; x < 5; ++x) {			
			pop += diff;
			System.out.println("The population after " + (x+1) + " years is " + pop);
		}
	}

}
